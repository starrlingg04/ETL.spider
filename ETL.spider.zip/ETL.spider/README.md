CodeIgniter 3.0.0 with Bootstrap
=====

## Features

- CodeIgniter 3.0.0
- Bootstrap v3.3.4 CDN


### Screenshots

![ci-bootstrap-screenshot](ci_bootstrap.png)

### License
- [MIT](http://opensource.org/licenses/MIT)


