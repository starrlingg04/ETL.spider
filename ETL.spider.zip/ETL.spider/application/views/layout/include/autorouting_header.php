<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Bootstrap core CSS -->
   <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
   <link href='https://fonts.googleapis.com/css?family=Exo' rel='stylesheet' type='text/css'>

   <title>ETL Spider tool</title>
   
   <style>
   body {
	  padding-top: 20px;
	  padding-bottom: 20px;
    font-family: 'Exo', sans-serif;
   }

   .navbar {
	  margin-bottom: 20px;
   }

   </style>

</head>
<body>
<div class="container">

  <!-- Static navbar -->
      <nav class="navbar navbar-default">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/ETL.spider/">ETL Spider Tool</a>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
              <li><a href="/ETL.spider/">Dashboard</a></li>
              <li class="dropdown active">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Autorouting <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="<?php echo site_url('home/autoroutingExtract') ?>">Extract</a></li>
                  <li><a href="#">Load</a></li>
                  <li><a href="#">Transform</a></li>
                </ul>
              </li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Sourcemapping <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="#">Extract</a></li>
                  <li><a href="#">Transform</a></li>
                </ul>
              </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
             
              <li><a href="<?php echo site_url('home/extract')?>"> Login</a></li>
            </ul>
          </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
      </nav>
