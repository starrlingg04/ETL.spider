 <div class="jumbotron">
 		<h3>Autorouting Extract</h3>
 		<h5>Default by: sourcename, apply_url, jobname, city, state, country, zip, company, recruiter_id, position, description </h5>
 	<br/>
 	<br/>

<table>
	<tr>
		<td> <h4>format : "json"</h4> </td>
	</tr>
		<td> <h4>name : "<input type="text">"</h4> </td>
	</tr>
	<tr>
		<td><h4>comments : "<input type="text">"</h4> </td>
	</tr>
	<tr>
	 	<td><h4>fields : [ ]</h4> </td>
	</tr>
</table>




</div>